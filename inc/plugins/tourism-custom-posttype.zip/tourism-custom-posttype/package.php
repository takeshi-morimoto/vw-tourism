<?php
function create_package_post_type() {
    $labels = array(
        'name'                  => _x( 'Packages', 'Post Type General Name', 'text_domain' ),
        'singular_name'         => _x( 'Package', 'Post Type Singular Name', 'text_domain' ),
        'menu_name'             => __( 'Packages', 'text_domain' ),
        'name_admin_bar'        => __( 'Package', 'text_domain' ),
        'archives'              => __( 'Package Archives', 'text_domain' ),
        'attributes'            => __( 'Package Attributes', 'text_domain' ),
        'parent_item_colon'     => __( 'Parent Package:', 'text_domain' ),
        'all_items'             => __( 'All Packages', 'text_domain' ),
        'add_new_item'          => __( 'Add New Package', 'text_domain' ),
        'add_new'               => __( 'Add New', 'text_domain' ),
        'new_item'              => __( 'New Package', 'text_domain' ),
        'edit_item'             => __( 'Edit Package', 'text_domain' ),
        'update_item'           => __( 'Update Package', 'text_domain' ),
        'view_item'             => __( 'View Package', 'text_domain' ),
        'view_items'            => __( 'View Packages', 'text_domain' ),
        'search_items'          => __( 'Search Package', 'text_domain' ),
        'not_found'             => __( 'Not found', 'text_domain' ),
        'not_found_in_trash'    => __( 'Not found in Trash', 'text_domain' ),
        'featured_image'        => __( 'Featured Image', 'text_domain' ),
        'set_featured_image'    => __( 'Set featured image', 'text_domain' ),
        'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
        'use_featured_image'    => __( 'Use as featured image', 'text_domain' ),
        'insert_into_item'      => __( 'Insert into package', 'text_domain' ),
        'uploaded_to_this_item' => __( 'Uploaded to this package', 'text_domain' ),
        'items_list'            => __( 'Packages list', 'text_domain' ),
        'items_list_navigation' => __( 'Packages list navigation', 'text_domain' ),
        'filter_items_list'     => __( 'Filter packages list', 'text_domain' ),
    );
    $args = array(
        'label'                 => __( 'Package', 'text_domain' ),
        'description'           => __( 'Tourism Packages', 'text_domain' ),
        'labels'                => $labels,
        'supports'              => array( 'title', 'editor', 'thumbnail', 'comments' ),
        'taxonomies'            => array( 'tcp_destination', 'tcp_team' ),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-palmtree',
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'page',
    );
    register_post_type( 'tcp_package', $args );
}
add_action( 'init', 'create_package_post_type', 0 );

add_action('add_meta_boxes', 'add_package_custom_meta_box');
function add_package_custom_meta_box() {
    add_meta_box(
        'package_custom_meta_box',
        'Additional Meta Fields',
        'render_package_custom_meta_box',
        'tcp_package',
        'normal',
        'default'
    );

    add_meta_box(
        'package_media_meta_box',
        'Additional Media Fields',
        'render_package_media_meta_box',
        'tcp_package',
        'normal',
        'default'
    );

    add_meta_box(
        'package_details_meta_box',
        'Package Details Fields',
        'render_package_details_meta_box',
        'tcp_package',
        'normal',
        'default'
    );
    add_meta_box(
        'package_additional_details_meta_box',
        'Package Additional Fields',
        'render_package_additional_details_meta_box',
        'tcp_package',
        'normal',
        'default'
    );
}

function render_package_details_meta_box($post) {

    $pkg_tour_details = get_post_meta($post->ID, 'pkg_tour_details', true);
    $pkg_tour_details_values = $pkg_tour_details ? $pkg_tour_details : array();
    $tour_days = get_post_meta($post->ID, 'pkg_tour_days', true);


    $tour_days_count = 0;

    if($tour_days){
        $tour_days_count = $tour_days;
    }
    ?>
    <div class="package-details-main">

        <?php
            for ($i=0; $i < $tour_days_count; $i++) {

                $image_link = isset($pkg_tour_details_values[$i]['image']) ? $pkg_tour_details_values[$i]['image'] : '';
                $description = isset($pkg_tour_details_values[$i]['description']) ? $pkg_tour_details_values[$i]['description'] : '';
                ?>
                <div class="package-details-main-fields">
                    <div>
                        <label for="pkg-tour-day<?php echo $i; ?>-image"><?php _e( 'Day ' . ($i + 1) . ' Image', 'text_domain' ); ?></label>
                        <input type="text" name="pkg-tour-details[<?php echo $i; ?>][image]" id="pkg-tour-day<?php echo $i; ?>-image" class="pkg-tour-days-field" value="<?php echo esc_attr($image_link); ?>" />
                        <input type="button" class="button button-secondary pkg-tour-image-upload" value="Upload Image" />
                    </div>
                    <div>
                        <label for="pkg-tour-day<?php echo $i; ?>-description"><?php _e( 'Day ' . ($i + 1) . ' Description', 'text_domain' ); ?></label>
                        <input type="text" name="pkg-tour-details[<?php echo $i; ?>][description]" id="pkg-tour-day<?php echo $i; ?>-description" class="pkg-tour-nights-field" value="<?php echo esc_attr($description); ?>" />
                    </div>
                </div>
            <?php }
        ?>

        <input type="hidden" name="pkg-tour-details-values" value="<?php echo esc_attr(json_encode($pkg_tour_details_values)); ?>" >
    </div>

<?php }

function render_package_custom_meta_box($post) {

    $pkg_from = get_post_meta($post->ID, 'pkg_from', true);
    $pkg_to = get_post_meta($post->ID, 'pkg_to', true);
    $tour_days = get_post_meta($post->ID, 'pkg_tour_days', true);
    $travel_name = get_post_meta($post->ID, 'pkg_travel_name', true);
    $pkg_person_text = get_post_meta($post->ID, 'pkg_person_text', true);
    $regular_price = get_post_meta($post->ID, 'pkg_regular_price', true);
    $sale_price = get_post_meta($post->ID, 'pkg_sale_price', true);
    $tour_nights = get_post_meta($post->ID, 'pkg_tour_nights', true);
    $tour_loc_latitude = get_post_meta($post->ID, 'pkg_tour_loc_latitude', true);
    $tour_loc_longitude = get_post_meta($post->ID, 'pkg_tour_loc_longitude', true);

    wp_nonce_field('save_package_custom_meta_box', 'package_custom_meta_box_nonce');
    ?>

    <div class="package-custom-meta-fields">

        <div>
            <label for="pkg-from"><?php _e( 'Package From', 'text_domain' ); ?></label>
            <input type="text" name="pkg-from" id="pkg-from" class="pkg-from-field" value="<?php echo esc_attr($pkg_from); ?>" />
        </div>
        <div>
            <label for="pkg-to"><?php _e( 'Package To', 'text_domain' ); ?></label>
            <input type="text" name="pkg-to" id="pkg-to" class="pkg-to-field" value="<?php echo esc_attr($pkg_to); ?>" />
        </div>
        <div>
            <label for="pkg-regular-price"><?php _e( 'Regular Price', 'text_domain' ); ?></label>
            <input type="number" name="pkg-regular-price" id="pkg-regular-price" class="pkg-regular-price-field" min="0" value="<?php echo esc_attr($regular_price); ?>" />
        </div>
        <div>
            <label for="pkg-sale-price"><?php _e( 'Sale Price', 'text_domain' ); ?></label>
            <input type="number" name="pkg-sale-price" id="pkg-sale-price" class="pkg-sale-price-field" min="0" value="<?php echo esc_attr($sale_price); ?>" />
        </div>
        <div>
            <label for="pkg-person-text"><?php _e( 'Per Person/Members', 'text_domain' ); ?></label>
            <input type="text" name="pkg-person-text" id="pkg-person-text" class="pkg-person-text-field" value="<?php echo esc_attr($pkg_person_text); ?>" />
        </div>
        <div>
            <label for="pkg-tour-days"><?php _e( 'Days', 'text_domain' ); ?></label>
            <input type="number" name="pkg-tour-days" id="pkg-tour-days" class="pkg-tour-days-field" min="0" value="<?php echo esc_attr($tour_days); ?>" />
        </div>
        <div>
            <label for="pkg-tour-nights"><?php _e( 'Nights', 'text_domain' ); ?></label>
            <input type="number" name="pkg-tour-nights" id="pkg-tour-nights" class="pkg-tour-nights-field" min="0" value="<?php echo esc_attr($tour_nights); ?>" />
        </div>
        <div>
            <label for="pkg-tour-loc-latitude"><?php _e( 'Location (Latitude)', 'text_domain' ); ?></label>
            <input type="number" name="pkg-tour-loc-latitude" id="pkg-tour-loc-latitude" class="pkg-tour-loc-latitude-field" step="any" value="<?php echo esc_attr($tour_loc_latitude); ?>" />
        </div>
        <div>
            <label for="pkg-tour-loc-longitude"><?php _e( 'Location (Longitude)', 'text_domain' ); ?></label>
            <input type="number" name="pkg-tour-loc-longitude" id="pkg-tour-loc-longitude" class="pkg-tour-loc-longitude-field" step="any" value="<?php echo esc_attr($tour_loc_longitude); ?>" />
        </div>
        <div>
            <label for="pkg-travel-name"><?php _e( 'Travel Name', 'text_domain' ); ?></label>
            <input type="text" name="pkg-travel-name" id="pkg-travel-name" class="pkg-travel-name-field" value="<?php echo esc_attr($travel_name); ?>" />
        </div>
    </div>
    <style>
        .package-custom-meta-fields {
            display: flex;
            flex-wrap: wrap;
        }

        .package-custom-meta-fields > div {
            flex: 0 0 48%;
            padding-right: 10px;
        }

        .package-custom-meta-fields label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .package-custom-meta-fields input[type="text"],
        .package-custom-meta-fields input[type="number"] {
            width: 100%;
            padding: 5px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .package-custom-meta-fields input[type="number"] {
            -moz-appearance: textfield;
        }

        .package-custom-meta-fields input[type="number"]::-webkit-inner-spin-button,
        .package-custom-meta-fields input[type="number"]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        .package-custom-meta-fields input[type="number"] {
            -moz-appearance: textfield;
        }

        .package-custom-meta-fields input[type="number"]::-webkit-inner-spin-button,
        .package-custom-meta-fields input[type="number"]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
    </style>
<?php }

function render_package_media_meta_box($post) {

    $pkg_additional_image_1 = get_post_meta($post->ID, 'pkg_additional_image_1', true);
    $pkg_additional_image_2 = get_post_meta($post->ID, 'pkg_additional_image_2', true);
    $pkg_additional_video = get_post_meta($post->ID, 'pkg_additional_video', true);
    ?>

    <div class="package-media-meta-fields">
        <div class="field-parent">
            <label for="additional-image-1"><?php _e( 'Additional Image 1', 'text_domain' ); ?></label>
            <input type="text" name="additional-image-1" id="additional-image-1" class="additional-image-field" value="<?php echo esc_attr($pkg_additional_image_1); ?>"/>
            <input type="button" class="button button-secondary additional-image-upload" data-upload="image" value="<?php _e( 'Upload Image', 'text_domain' ); ?>" />
            <div class="additional-image-preview"></div>
        </div>
        <div class="field-parent">
            <label for="additional-image-2"><?php _e( 'Additional Image 2', 'text_domain' ); ?></label>
            <input type="text" name="additional-image-2" id="additional-image-2" class="additional-image-field" value="<?php echo esc_attr($pkg_additional_image_2); ?>"/>
            <input type="button" class="button button-secondary additional-image-upload" data-upload="image" value="<?php _e( 'Upload Image', 'text_domain' ); ?>" />
            <div class="additional-image-preview"></div>
        </div>
        <div class="field-parent">
            <label for="additional-video"><?php _e( 'Additional Video', 'text_domain' ); ?></label>
            <input type="text" name="additional-video" id="additional-video" class="additional-video-field" value="<?php echo esc_attr($pkg_additional_video); ?>"/>
            <input type="button" class="button button-secondary additional-video-upload" data-upload="video" value="<?php _e( 'Upload Video', 'text_domain' ); ?>" />
            <div class="additional-video-preview"></div>
        </div>
    </div>
    <style>
        .package-media-meta-fields {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .package-media-meta-fields > div {
            display: flex;
            flex-direction: column;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
        }

        input[type="text"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .button-secondary {
            background-color: #f0f0f0;
            color: #333;
            border: 1px solid #ccc;
            border-radius: 4px;
            padding: 8px 16px;
            cursor: pointer;
        }

        .additional-image-preview {
            margin-top: 5px;
            max-width: 200px; /* adjust as needed */
        }

        .additional-image-preview img {
            max-width: 100%;
            height: auto;
        }
    </style>
<?php }

function package_taxonomy_image_script() {
    ?>
    <script>
        jQuery(document).ready(function($){

            var file_frame_video;
            $(document).on('click', '.additional-video-upload', function(event){
                event.preventDefault();
                var $button = $(this);

                const upload_type = $button.attr('data-upload');

                $fieldparent = $button.closest('.field-parent');
                // If the media frame already exists, reopen it.
                if ( file_frame_video ) {
                    file_frame_video.open();
                    return;
                }

                // Create the media frame.
                file_frame_video = wp.media.frames.file_frame_video = wp.media({
                    title: '<?php _e( "Select or Upload Image", "text_domain" ); ?>',
                    button: {
                        text: '<?php _e( "Select", "text_domain" ); ?>'
                    },
                    library: {
                        type: [ 'video' ]
                    },
                    multiple: false
                });

                // When an image is selected, run a callback.
                file_frame_video.on( 'select', function() {
                    var attachment = file_frame_video.state().get('selection').first().toJSON();

                    if ( upload_type == 'video' && attachment.type == 'video' ) {
                        $fieldparent.find('.additional-video-field').val(attachment.url);
                    }
                    if ( upload_type == 'video' && attachment.type !== 'video' ) {
                        alert("Please select a video file.");
                    }

                    file_frame_video.close();

                });

                // Finally, open the modal.
                file_frame_video.open();
            });

            // uploading package tour details
            var pkg_tour_details;
            $(document).on('click', '.pkg-tour-image-upload', function(event){
                event.preventDefault();
                var $button = $(this);

                $fieldparent = $button.closest('.package-details-main-fields');
                // If the media frame already exists, reopen it.
                if ( pkg_tour_details ) {
                    pkg_tour_details.open();
                    return;
                }
                // Create the media frame.
                pkg_tour_details = wp.media.frames.pkg_tour_details = wp.media({
                    title: '<?php _e( "Select or Upload Image", "text_domain" ); ?>',
                    button: {
                        text: '<?php _e( "Select", "text_domain" ); ?>'
                    },
                    library: {
                        type: [ 'image' ]
                    },
                    multiple: false
                });
                // When an image is selected, run a callback.
                pkg_tour_details.on( 'select', function() {
                    var attachment = pkg_tour_details.state().get('selection').first().toJSON();

                    $fieldparent.find('.pkg-tour-days-field').val(attachment.url);

                    pkg_tour_details.close();

                });

                // Finally, open the modal.
                pkg_tour_details.open();
            });

            // Uploading files
            var file_frame_image;
            $(document).on('click', '.additional-image-upload', function(event){
                event.preventDefault();
                var $button = $(this);

                const upload_type = $button.attr('data-upload');

                $fieldparent = $button.closest('.field-parent');
                // If the media frame already exists, reopen it.
                if ( file_frame_image ) {
                    file_frame_image.open();
                    return;
                }
                // Create the media frame.
                file_frame_image = wp.media.frames.file_frame_image = wp.media({
                    title: '<?php _e( "Select or Upload Image", "text_domain" ); ?>',
                    button: {
                        text: '<?php _e( "Select", "text_domain" ); ?>'
                    },
                    library: {
                        type: [ 'image' ]
                    },
                    multiple: false
                });
                // When an image is selected, run a callback.
                file_frame_image.on( 'select', function() {
                    var attachment = file_frame_image.state().get('selection').first().toJSON();

                    if ( upload_type == 'image' && attachment.type == 'image' ) {
                        $fieldparent.find('.additional-image-field').val(attachment.url);
                        $fieldparent.find('.additional-image-preview').html('<img src="' + attachment.url + '" alt="" style="width: 200px; height: auto;">');
                    }

                    file_frame_image.close();

                });

                // Finally, open the modal.
                file_frame_image.open();
            });

            $('#pkg-tour-days').on( 'input', function() {

                var package_details = $('[name="pkg-tour-details-values"]').val();
                package_details = JSON.parse(package_details);

                const days_count = $('[name="pkg-tour-days"]').val();

                const package_details_main = $('.package-details-main');

                package_details_main.find(':not(input[name="pkg-tour-details-values"])').remove();

                for (let index = 0; index < days_count; index++) {

                    let image_link = '';
                    let description = '';

                    if (index < package_details.length) {
                        image_link = package_details[index].image ? package_details[index].image : '';
                        description = package_details[index].description ? package_details[index].description : '';
                    }

                    package_details_main.append(`
                        <div class="package-details-main-fields">
                            <div>
                                <label for="pkg-tour-day`+index+`-image">Day `+ (index + 1) +` Image</label>
                                <input type="text" name="pkg-tour-details[`+index+`][image]" id="pkg-tour-day`+index+`-image" class="pkg-tour-days-field" value="`+image_link+`" />
                                <input type="button" class="button button-secondary pkg-tour-image-upload" value="Upload Image" />
                            </div>
                            <div>
                                <label for="pkg-tour-day`+index+`-description">Day `+ (index + 1) +` Description</label>
                                <input type="text" name="pkg-tour-details[`+index+`][description]" id="pkg-tour-day`+index+`-description" class="pkg-tour-nights-field" value="`+description+`" />
                            </div>
                        </div>
                    `);
                }

            });
        });
    </script>
    <?php
}
add_action( 'admin_footer', 'package_taxonomy_image_script' );

function save_package_custom_meta_box($post_id) {

    if (!isset($_POST['package_custom_meta_box_nonce'])) {
        return;
    }
    if (!wp_verify_nonce($_POST['package_custom_meta_box_nonce'], 'save_package_custom_meta_box')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    if ( isset( $_POST['pkg-from'] ) ) {
        $pkg_from = $_POST['pkg-from'];
        update_post_meta( $post_id, 'pkg_from', $pkg_from );
    }

    if ( isset( $_POST['pkg-tour-details'] ) ) {
        $pkg_tour_details = $_POST['pkg-tour-details'];
        update_post_meta( $post_id, 'pkg_tour_details', $pkg_tour_details );
    }

    if ( isset( $_POST['additional_info'] ) ) {
        $additional_info = $_POST['additional_info'];
        update_post_meta( $post_id, 'pkg_tour_additional_info', $additional_info );
    }

    if ( isset( $_POST['pkg-to'] ) ) {
        $pkg_to = $_POST['pkg-to'];
        update_post_meta( $post_id, 'pkg_to', $pkg_to );
    }

    if ( isset( $_POST['pkg-travel-name'] ) ) {
        $pkg_travel_name = $_POST['pkg-travel-name'];
        update_post_meta( $post_id, 'pkg_travel_name', $pkg_travel_name );
    }

    if ( isset( $_POST['pkg-regular-price'] ) ) {
        $pkg_regular_price = $_POST['pkg-regular-price'];
        update_post_meta( $post_id, 'pkg_regular_price', $pkg_regular_price );
    }
    
    if ( isset( $_POST['pkg-person-text'] ) ) {
        $pkg_person_text = $_POST['pkg-person-text'];
        update_post_meta( $post_id, 'pkg_person_text', $pkg_person_text );
    }

    if ( isset( $_POST['pkg-sale-price'] ) ) {
        $pkg_sale_price = $_POST['pkg-sale-price'];
        update_post_meta( $post_id, 'pkg_sale_price', $pkg_sale_price );
    }

    if ( isset( $_POST['pkg-tour-days'] ) ) {
        $pkg_tour_days = $_POST['pkg-tour-days'];
        update_post_meta( $post_id, 'pkg_tour_days', $pkg_tour_days );
    }

    if ( isset( $_POST['pkg-tour-nights'] ) ) {
        $pkg_tour_nights = $_POST['pkg-tour-nights'];
        update_post_meta( $post_id, 'pkg_tour_nights', $pkg_tour_nights );
    }

    if ( isset( $_POST['pkg-tour-loc-latitude'] ) ) {
        $tour_loc_latitude = $_POST['pkg-tour-loc-latitude'];
        update_post_meta( $post_id, 'pkg_tour_loc_latitude', $tour_loc_latitude );
    }

    if ( isset( $_POST['pkg-tour-loc-longitude'] ) ) {
        $tour_loc_longitude = $_POST['pkg-tour-loc-longitude'];
        update_post_meta( $post_id, 'pkg_tour_loc_longitude', $tour_loc_longitude );
    }

    if ( isset( $_POST['additional-image-1'] ) ) {
        $additional_image_1 = $_POST['additional-image-1'];
        update_post_meta( $post_id, 'pkg_additional_image_1', $additional_image_1 );
    }

    if ( isset( $_POST['additional-image-2'] ) ) {
        $additional_image_2 = $_POST['additional-image-2'];
        update_post_meta( $post_id, 'pkg_additional_image_2', $additional_image_2 );
    }

    if ( isset( $_POST['additional-video'] ) ) {
        $additional_video = $_POST['additional-video'];
        update_post_meta( $post_id, 'pkg_additional_video', $additional_video );
    }
}
add_action('save_post', 'save_package_custom_meta_box');

function render_package_additional_details_meta_box($post) {
    $pkg_tour_additional_info = get_post_meta($post->ID, 'pkg_tour_additional_info', true);

    wp_nonce_field('save_package_custom_meta_box', 'package_custom_meta_box_nonce');

    wp_editor($pkg_tour_additional_info, 'additional_info', array(
        'textarea_name' => 'additional_info',
        'media_buttons' => true,
        'textarea_rows' => 10,
        'teeny' => false
    ));
}
