<?php
function create_team_taxonomy() {

	$labels = array(
		'name'                       => _x( 'Teams', 'Taxonomy General Name', 'text_domain' ),
		'singular_name'              => _x( 'Team', 'Taxonomy Singular Name', 'text_domain' ),
		'menu_name'                  => __( 'Team', 'text_domain' ),
		'all_items'                  => __( 'All Teams', 'text_domain' ),
		'parent_item'                => __( 'Parent Team', 'text_domain' ),
		'parent_item_colon'          => __( 'Parent Team:', 'text_domain' ),
		'new_item_name'              => __( 'New Team Name', 'text_domain' ),
		'add_new_item'               => __( 'Add New Team', 'text_domain' ),
		'edit_item'                  => __( 'Edit Team', 'text_domain' ),
		'update_item'                => __( 'Update Team', 'text_domain' ),
		'view_item'                  => __( 'View Team', 'text_domain' ),
		'separate_items_with_commas' => __( 'Separate teams with commas', 'text_domain' ),
		'add_or_remove_items'        => __( 'Add or remove teams', 'text_domain' ),
		'choose_from_most_used'      => __( 'Choose from the most used', 'text_domain' ),
		'popular_items'              => __( 'Popular Teams', 'text_domain' ),
		'search_items'               => __( 'Search Teams', 'text_domain' ),
		'not_found'                  => __( 'Not Found', 'text_domain' ),
		'no_terms'                   => __( 'No teams', 'text_domain' ),
		'items_list'                 => __( 'Teams list', 'text_domain' ),
		'items_list_navigation'      => __( 'Teams list navigation', 'text_domain' ),
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
	);
	register_taxonomy( 'tcp_team', array( 'tcp_package' ), $args );

}
add_action( 'init', 'create_team_taxonomy', 0 );

function add_team_taxonomy_fields() {
    ?>
    <div class="form-field">

        <label for="team-role"><?php _e( 'Role', 'text_domain' ); ?></label>
        <input type="text" name="team-role" id="team-role" class="team-role-field" value="" style="width: 100%;" /><br><br>

        <label for="team-dob"><?php _e( 'DOB', 'text_domain' ); ?></label>
        <input type="date" name="team-dob" id="team-dob" class="team-dob-field" value="" style="width: 100%;" /><br><br>

        <label for="team-address"><?php _e( 'Address', 'text_domain' ); ?></label>
        <input type="text" name="team-address" id="team-address" class="team-address-field" value="" style="width: 100%;" /><br><br>

        <label for="team-email"><?php _e( 'Email', 'text_domain' ); ?></label>
        <input type="email" name="team-email" id="team-email" class="team-email-field" value="" style="width: 100%;" /><br><br>

        <label for="team-phone"><?php _e( 'Phone', 'text_domain' ); ?></label>
        <input type="text" name="team-phone" id="team-phone" class="team-phone-field" value="" style="width: 100%;" /><br><br>

        <label for="team-experience"><?php _e( 'Experience', 'text_domain' ); ?></label>
        <input type="text" name="team-experience" id="team-experience" class="team-experience-field" value="" style="width: 100%;" /><br><br>

        <label for="team-clients"><?php _e( 'Clients', 'text_domain' ); ?></label>
        <input type="text" name="team-clients" id="team-clients" class="team-clients-field" value="" style="width: 100%;" /><br><br>

        <label for="team-awards"><?php _e( 'Awards', 'text_domain' ); ?></label>
        <input type="text" name="team-awards" id="team-awards" class="team-awards-field" value="" style="width: 100%;" /><br><br>

        <label for="team-client-satisfied"><?php _e( 'Client Satisfied', 'text_domain' ); ?></label>
        <input type="text" name="team-client-satisfied" id="team-client-satisfied" class="team-client-satisfied-field" value="" style="width: 100%;" /><br><br>

        <label for="team-image"><?php _e( 'Profile Image', 'text_domain' ); ?></label>
        <input type="text" name="team-image" id="team-image" class="team-image-field" value="" style="width: 100%;" />
        <input type="button" class="button button-secondary team-image-upload" value="<?php _e( 'Upload Image', 'text_domain' ); ?>" />
        <p class="description"><?php _e( 'Upload or select a team image.', 'text_domain' ); ?></p>
        <div class="team-image-preview"></div>
    </div>
    <?php
}
add_action( 'tcp_team_add_form_fields', 'add_team_taxonomy_fields', 10, 2 );

function team_taxonomy_image_script() {
    ?>
    <script>
        jQuery(document).ready(function($){
            // Uploading files
            var file_frame;
            $(document).on('click', '.team-image-upload', function(event){
                event.preventDefault();
                var $button = $(this);
                // If the media frame already exists, reopen it.
                if ( file_frame ) {
                    file_frame.open();
                    return;
                }
                // Create the media frame.
                file_frame = wp.media.frames.file_frame = wp.media({
                    title: '<?php _e( "Select or Upload Team Image", "text_domain" ); ?>',
                    button: {
                        text: '<?php _e( "Use this Image", "text_domain" ); ?>'
                    },
                    multiple: false
                });
                // When an image is selected, run a callback.
                file_frame.on( 'select', function() {
                    var attachment = file_frame.state().get('selection').first().toJSON();
                    $button.siblings('.team-image-field').val(attachment.url);
                    $button.siblings('.team-image-preview').html('<img src="' + attachment.url + '" alt="" style="width: 200px; height: auto;">');
                });
                // Finally, open the modal.
                file_frame.open();
            });
        });
    </script>
    <?php
}
add_action( 'admin_footer', 'team_taxonomy_image_script' );

function update_team_taxonomy_fields( $term_id ) {
    if ( isset( $_POST['team-image'] ) ) {
        $image = $_POST['team-image'];
        update_term_meta( $term_id, 'team_image', $image );
    }

    if ( isset( $_POST['team-dob'] ) ) {
        $team_dob = $_POST['team-dob'];
        update_term_meta( $term_id, 'team_dob', $team_dob );
    }

    if ( isset( $_POST['team-address'] ) ) {
        $team_address = $_POST['team-address'];
        update_term_meta( $term_id, 'team_address', $team_address );
    }

    if ( isset( $_POST['team-email'] ) ) {
        $team_email = $_POST['team-email'];
        update_term_meta( $term_id, 'team_email', $team_email );
    }

    if ( isset( $_POST['team-phone'] ) ) {
        $team_phone = $_POST['team-phone'];
        update_term_meta( $term_id, 'team_phone', $team_phone );
    }

    if ( isset( $_POST['team-experience'] ) ) {
        $team_experience = $_POST['team-experience'];
        update_term_meta( $term_id, 'team_experience', $team_experience );
    }

    if ( isset( $_POST['team-clients'] ) ) {
        $team_clients = $_POST['team-clients'];
        update_term_meta( $term_id, 'team_clients', $team_clients );
    }

    if ( isset( $_POST['team-awards'] ) ) {
        $team_awards = $_POST['team-awards'];
        update_term_meta( $term_id, 'team_awards', $team_awards );
    }

    if ( isset( $_POST['team-client-satisfied'] ) ) {
        $team_client_satisfied = $_POST['team-client-satisfied'];
        update_term_meta( $term_id, 'team_client_satisfied', $team_client_satisfied );
    }

    if ( isset( $_POST['team-role'] ) ) {
        $team_role = $_POST['team-role'];
        update_term_meta( $term_id, 'team_role', $team_role );
    }
}
add_action( 'edited_tcp_team', 'update_team_taxonomy_fields', 10, 2 );
add_action( 'created_tcp_team', 'update_team_taxonomy_fields', 10, 2 );

function edit_team_taxonomy_fields( $term ) {

    $team_image = get_term_meta( $term->term_id, 'team_image', true );
    $team_dob = get_term_meta( $term->term_id, 'team_dob', true );
    $team_address = get_term_meta( $term->term_id, 'team_address', true );
    $team_email = get_term_meta( $term->term_id, 'team_email', true );
    $team_phone = get_term_meta( $term->term_id, 'team_phone', true );
    $team_experience = get_term_meta( $term->term_id, 'team_experience', true );
    $team_clients = get_term_meta( $term->term_id, 'team_clients', true );
    $team_awards = get_term_meta( $term->term_id, 'team_awards', true );
    $team_client_satisfied = get_term_meta( $term->term_id, 'team_client_satisfied', true );
    $team_role = get_term_meta( $term->term_id, 'team_role', true );
    ?>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="team-role"><?php _e( 'Role', 'text_domain' ); ?></label></th>
        <td>
            <input type="text" name="team-role" id="team-role" class="team-role-field" value="<?php echo esc_attr( $team_role ); ?>" style="width: 100%;" />
        </td>
    </tr>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="team-dob"><?php _e( 'Team DOB', 'text_domain' ); ?></label></th>
        <td>
            <input type="date" name="team-dob" id="team-dob" class="team-dob-field" value="<?php echo esc_attr( $team_dob ); ?>" style="width: 100%;" />
        </td>
    </tr>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="team-address"><?php _e( 'Address', 'text_domain' ); ?></label></th>
        <td>
            <input type="text" name="team-address" id="team-address" class="team-address-field" value="<?php echo esc_attr( $team_address ); ?>" style="width: 100%;" />
        </td>
    </tr>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="team-email"><?php _e( 'Email', 'text_domain' ); ?></label></th>
        <td>
            <input type="email" name="team-email" id="team-email" class="team-email-field" value="<?php echo esc_attr( $team_email ); ?>" style="width: 100%;" />
        </td>
    </tr>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="team-phone"><?php _e( 'Phone', 'text_domain' ); ?></label></th>
        <td>
            <input type="text" name="team-phone" id="team-phone" class="team-phone-field" value="<?php echo esc_attr( $team_phone ); ?>" style="width: 100%;" />
        </td>
    </tr>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="team-experience"><?php _e( 'Experience', 'text_domain' ); ?></label></th>
        <td>
            <input type="text" name="team-experience" id="team-experience" class="team-experience-field" value="<?php echo esc_attr( $team_experience ); ?>" style="width: 100%;" />
        </td>
    </tr>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="team-clients"><?php _e( 'Clients', 'text_domain' ); ?></label></th>
        <td>
            <input type="text" name="team-clients" id="team-clients" class="team-clients-field" value="<?php echo esc_attr( $team_clients ); ?>" style="width: 100%;" />
        </td>
    </tr>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="team-awards"><?php _e( 'Awards', 'text_domain' ); ?></label></th>
        <td>
            <input type="text" name="team-awards" id="team-awards" class="team-awards-field" value="<?php echo esc_attr( $team_awards ); ?>" style="width: 100%;" />
        </td>
    </tr>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="team-client-satisfied"><?php _e( 'Client Satisfied', 'text_domain' ); ?></label></th>
        <td>
            <input type="text" name="team-client-satisfied" id="team-client-satisfied" class="team-client-satisfied-field" value="<?php echo esc_attr( $team_client_satisfied ); ?>" style="width: 100%;" />
        </td>
    </tr>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="team-image"><?php _e( 'Profile Image', 'text_domain' ); ?></label></th>
        <td>
            <input type="text" name="team-image" id="team-image" class="team-image-field" value="<?php echo esc_attr( $team_image ); ?>" style="width: 100%;" />
            <input type="button" class="button button-secondary team-image-upload" value="<?php _e( 'Upload Image', 'text_domain' ); ?>" />
            <p class="description"><?php _e( 'Upload or select a team image.', 'text_domain' ); ?></p>
            <div class="team-image-preview">
                <?php if ( ! empty( $team_image ) ) : ?>
                    <img src="<?php echo esc_url( $team_image ); ?>" alt="" style="width: 200px; height: auto;">
                <?php endif; ?>
            </div>
        </td>
    </tr>
    <?php
}
add_action( 'tcp_team_edit_form_fields', 'edit_team_taxonomy_fields', 10, 2 );
