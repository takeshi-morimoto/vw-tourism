<?php
function create_destination_taxonomy() {

	$labels = array(
		'name'                       => _x( 'Destinations', 'Taxonomy General Name', 'text_domain' ),
		'singular_name'              => _x( 'Destination', 'Taxonomy Singular Name', 'text_domain' ),
		'menu_name'                  => __( 'Destination', 'text_domain' ),
		'all_items'                  => __( 'All Destinations', 'text_domain' ),
		'parent_item'                => __( 'Parent Destination', 'text_domain' ),
		'parent_item_colon'          => __( 'Parent Destination:', 'text_domain' ),
		'new_item_name'              => __( 'New Destination Name', 'text_domain' ),
		'add_new_item'               => __( 'Add New Destination', 'text_domain' ),
		'edit_item'                  => __( 'Edit Destination', 'text_domain' ),
		'update_item'                => __( 'Update Destination', 'text_domain' ),
		'view_item'                  => __( 'View Destination', 'text_domain' ),
		'separate_items_with_commas' => __( 'Separate destinations with commas', 'text_domain' ),
		'add_or_remove_items'        => __( 'Add or remove destinations', 'text_domain' ),
		'choose_from_most_used'      => __( 'Choose from the most used', 'text_domain' ),
		'popular_items'              => __( 'Popular Destinations', 'text_domain' ),
		'search_items'               => __( 'Search Destinations', 'text_domain' ),
		'not_found'                  => __( 'Not Found', 'text_domain' ),
		'no_terms'                   => __( 'No destinations', 'text_domain' ),
		'items_list'                 => __( 'Destinations list', 'text_domain' ),
		'items_list_navigation'      => __( 'Destinations list navigation', 'text_domain' ),
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
	);
	register_taxonomy( 'tcp_destination', array( 'tcp_package' ), $args );

}
add_action( 'init', 'create_destination_taxonomy', 0 );

// create additional image field for the destination taxonomy start
// Add Custom Field for Taxonomy Term
function add_destination_taxonomy_fields() {
    ?>
    <div class="form-field">
        <label for="destination-type"><?php _e( 'Destination Type', 'text_domain' ); ?></label>
        <input type="text" name="destination-type" id="destination-type" class="destination-type-field" value="" style="width: 100%;" /><br><br>

        <label for="destination-image"><?php _e( 'Destination Image', 'text_domain' ); ?></label>
        <input type="text" name="destination-image" id="destination-image" class="destination-image-field" value="" style="width: 100%;" />
        <input type="button" class="button button-secondary destination-image-upload" value="<?php _e( 'Upload Image', 'text_domain' ); ?>" />
        <p class="description"><?php _e( 'Upload or select a destination image.', 'text_domain' ); ?></p>
        <div class="destination-image-preview"></div>
    </div>
    <?php
}
add_action( 'tcp_destination_add_form_fields', 'add_destination_taxonomy_fields', 10, 2 );

// Edit and Save Custom Field for Taxonomy Term
function edit_destination_taxonomy_fields( $term ) {
    $image = get_term_meta( $term->term_id, 'destination_image', true );
    $destination_type = get_term_meta( $term->term_id, 'destination_type', true );
    ?>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="destination-type"><?php _e( 'Destination Type', 'text_domain' ); ?></label></th>
        <td>
            <input type="text" name="destination-type" id="destination-type" class="destination-type-field" value="<?php echo esc_attr( $destination_type ); ?>" style="width: 100%;" />
        </td>
    </tr>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="destination-image"><?php _e( 'Destination Image', 'text_domain' ); ?></label></th>
        <td>
            <input type="text" name="destination-image" id="destination-image" class="destination-image-field" value="<?php echo esc_attr( $image ); ?>" style="width: 100%;" />
            <input type="button" class="button button-secondary destination-image-upload" value="<?php _e( 'Upload Image', 'text_domain' ); ?>" />
            <p class="description"><?php _e( 'Upload or select a destination image.', 'text_domain' ); ?></p>
            <div class="destination-image-preview">
                <?php if ( ! empty( $image ) ) : ?>
                    <img src="<?php echo esc_url( $image ); ?>" alt="" style="width: 200px; height: auto;">
                <?php endif; ?>
            </div>
        </td>
    </tr>
    <?php
}
add_action( 'tcp_destination_edit_form_fields', 'edit_destination_taxonomy_fields', 10, 2 );

// Script for Image Upload
function destination_taxonomy_image_script() {
    ?>
    <script>
        jQuery(document).ready(function($){
            // Uploading files
            var file_frame;
            $(document).on('click', '.destination-image-upload', function(event){
                event.preventDefault();
                var $button = $(this);
                // If the media frame already exists, reopen it.
                if ( file_frame ) {
                    file_frame.open();
                    return;
                }
                // Create the media frame.
                file_frame = wp.media.frames.file_frame = wp.media({
                    title: '<?php _e( "Select or Upload Destination Image", "text_domain" ); ?>',
                    button: {
                        text: '<?php _e( "Use this Image", "text_domain" ); ?>'
                    },
                    multiple: false
                });
                // When an image is selected, run a callback.
                file_frame.on( 'select', function() {
                    var attachment = file_frame.state().get('selection').first().toJSON();
                    $button.siblings('.destination-image-field').val(attachment.url);
                    $button.siblings('.destination-image-preview').html('<img src="' + attachment.url + '" alt="" style="width: 200px; height: auto;">');
                });
                // Finally, open the modal.
                file_frame.open();
            });
        });
    </script>
    <?php
}
add_action( 'admin_footer', 'destination_taxonomy_image_script' );
// create additional image field for the destination taxonomy end

function update_destination_taxonomy_fields( $term_id ) {
    if ( isset( $_POST['destination-image'] ) ) {
        $image = $_POST['destination-image'];
        update_term_meta( $term_id, 'destination_image', $image );
    }

    if ( isset( $_POST['destination-type'] ) ) {
        $destination_type = $_POST['destination-type'];
        update_term_meta( $term_id, 'destination_type', $destination_type );
    }
}
add_action( 'edited_tcp_destination', 'update_destination_taxonomy_fields', 10, 2 );
add_action( 'created_tcp_destination', 'update_destination_taxonomy_fields', 10, 2 );
