<?php
/**
* Plugin Name: Tourism Posttype Plugin
* Plugin URI:
* Description: A custom posttype plugin for the tourism theme.
* Version: 0.0.1
* Author: tourism-custom-posttype
* Text Domain: tourism-custom-posttype
* Author URI:
**/

define( 'TCP_FILE', __FILE__ );
define( 'TCP_DIR', plugin_dir_path( TCP_FILE ) );

function enqueue_media() {
    if ( function_exists( 'wp_enqueue_media' ) && !wp_script_is( 'media-upload' ) ) {
        wp_enqueue_media();
    }
}

add_action( 'admin_enqueue_scripts', 'enqueue_media' );

require_once TCP_DIR . 'posttypes.php';
require_once TCP_DIR . 'package.php';
require_once TCP_DIR . 'destination.php';
require_once TCP_DIR . 'categories.php';
require_once TCP_DIR . 'team.php';
require_once TCP_DIR . 'explore.php';
require_once TCP_DIR . 'todelete/popular-destination.php';
