<?php
function create_category_taxonomy() {

	$labels = array(
		'name'                       => _x( 'Categories', 'Taxonomy General Name', 'text_domain' ),
		'singular_name'              => _x( 'Category', 'Taxonomy Singular Name', 'text_domain' ),
		'menu_name'                  => __( 'Category', 'text_domain' ),
		'all_items'                  => __( 'All Categories', 'text_domain' ),
		'parent_item'                => __( 'Parent Category', 'text_domain' ),
		'parent_item_colon'          => __( 'Parent Category:', 'text_domain' ),
		'new_item_name'              => __( 'New Category Name', 'text_domain' ),
		'add_new_item'               => __( 'Add New Category', 'text_domain' ),
		'edit_item'                  => __( 'Edit Category', 'text_domain' ),
		'update_item'                => __( 'Update Category', 'text_domain' ),
		'view_item'                  => __( 'View Category', 'text_domain' ),
		'separate_items_with_commas' => __( 'Separate categories with commas', 'text_domain' ),
		'add_or_remove_items'        => __( 'Add or remove categories', 'text_domain' ),
		'choose_from_most_used'      => __( 'Choose from the most used', 'text_domain' ),
		'popular_items'              => __( 'Popular Categories', 'text_domain' ),
		'search_items'               => __( 'Search Categories', 'text_domain' ),
		'not_found'                  => __( 'Not Found', 'text_domain' ),
		'no_terms'                   => __( 'No categories', 'text_domain' ),
		'items_list'                 => __( 'Categories list', 'text_domain' ),
		'items_list_navigation'      => __( 'Categories list navigation', 'text_domain' ),
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
	);
	register_taxonomy( 'tcp_category', array( 'tcp_package' ), $args );

}
add_action( 'init', 'create_category_taxonomy', 0 );

// create additional image field for the Category taxonomy start
// Add Custom Field for Taxonomy Term
function add_category_taxonomy_fields() {
    ?>
    <div class="form-field">
        <label for="category-image"><?php _e( 'Category Image', 'text_domain' ); ?></label>
        <input type="text" name="category-image" id="category-image" class="category-image-field" value="" style="width: 100%;" />
        <input type="button" class="button button-secondary category-image-upload" value="<?php _e( 'Upload Image', 'text_domain' ); ?>" />
        <p class="description"><?php _e( 'Upload or select a category image.', 'text_domain' ); ?></p>
        <div class="category-image-preview"></div>
    </div>
    <?php
}
add_action( 'tcp_category_add_form_fields', 'add_category_taxonomy_fields', 10, 2 );


// Edit and Save Custom Field for Taxonomy Term
function edit_category_taxonomy_fields( $term ) {
    $image = get_term_meta( $term->term_id, 'category_image', true );
    ?>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="category-image"><?php _e( 'Category Image', 'text_domain' ); ?></label></th>
        <td>
            <input type="text" name="category-image" id="category-image" class="category-image-field" value="<?php echo esc_attr( $image ); ?>" style="width: 100%;" />
            <input type="button" class="button button-secondary category-image-upload" value="<?php _e( 'Upload Image', 'text_domain' ); ?>" />
            <p class="description"><?php _e( 'Upload or select a Category image.', 'text_domain' ); ?></p>
            <div class="category-image-preview">
                <?php if ( ! empty( $image ) ) : ?>
                    <img src="<?php echo esc_url( $image ); ?>" alt="" style="width: 200px; height: auto;">
                <?php endif; ?>
            </div>
        </td>
    </tr>
    <?php
}
add_action( 'tcp_category_edit_form_fields', 'edit_category_taxonomy_fields', 10, 2 );



// Script for Image Upload
function category_taxonomy_image_script() {
    ?>
    <script>
        jQuery(document).ready(function($){
            // Uploading files
            var file_frame;
            $(document).on('click', '.category-image-upload', function(event){
                event.preventDefault();
                var $button = $(this);
                // If the media frame already exists, reopen it.
                if ( file_frame ) {
                    file_frame.open();
                    return;
                }
                // Create the media frame.
                file_frame = wp.media.frames.file_frame = wp.media({
                    title: '<?php _e( "Select or Upload Category Image", "text_domain" ); ?>',
                    button: {
                        text: '<?php _e( "Use this Image", "text_domain" ); ?>'
                    },
                    multiple: false
                });
                // When an image is selected, run a callback.
                file_frame.on( 'select', function() {
                    var attachment = file_frame.state().get('selection').first().toJSON();
                    $button.siblings('.category-image-field').val(attachment.url);
                    $button.siblings('.category-image-preview').html('<img src="' + attachment.url + '" alt="" style="width: 200px; height: auto;">');
                });
                // Finally, open the modal.
                file_frame.open();
            });
        });
    </script>
    <?php
}
add_action( 'admin_footer', 'category_taxonomy_image_script' );
// create additional image field for the destination taxonomy end



function update_category_taxonomy_fields( $term_id ) {
    if ( isset( $_POST['category-image'] ) ) {
        $image = $_POST['category-image'];
        update_term_meta( $term_id, 'category_image', $image );
    }

}
add_action( 'edited_tcp_category', 'update_category_taxonomy_fields', 10, 2 );
add_action( 'created_tcp_category', 'update_category_taxonomy_fields', 10, 2 );
