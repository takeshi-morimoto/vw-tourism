<?php
function render_destination_section_function() {
    $destinations = get_terms( array(
        'taxonomy'   => 'tcp_destination',
        'hide_empty' => false,
    ) );

    $html = ob_start();

    foreach ($destinations as $destination) {
        
        $term_id = $destination->term_id;
        $term_name = $destination->name;

        $destination_image = get_term_meta( $term_id, 'destination-image', true );
        $destination_type = get_term_meta( $term_id, 'destination-type', true );

        ?>
        
    <?php }

    $html = ob_get_clean();
    return $html;

}
add_shortcode( 'destination-section', 'render_destination_section_function' );

function render_team_section_function() {
    $teams = get_terms( array(
        'taxonomy'   => 'tcp_team',
        'hide_empty' => false,
    ) );

    $html = ob_start();

    foreach ($teams as $team) {
        
        $term_id = $team->term_id;
        $term_name = $team->name;

        $team_role = get_term_meta( $term_id, 'team_role', true );

        ?>
        
    <?php }

    $html = ob_get_clean();
    return $html;

}
add_shortcode( 'team-section', 'render_team_section_function' );