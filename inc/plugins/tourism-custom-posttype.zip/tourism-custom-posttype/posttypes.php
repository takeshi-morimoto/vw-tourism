<?php
add_action( 'init', 'vw_tourism_pro_posttype_create_testimonial' );
add_action( 'init', 'vw_tourism_pro_posttype_create_popular_cuisines' );
add_action( 'init', 'vw_tourism_pro_posttype_create_experience' );

function vw_tourism_pro_posttype_create_testimonial() {
  register_post_type( 'testimonial',
    array(
  		'labels' => array(
  			'name' => __( 'Testimonial','vw-tourism-pro-posttype' ),
  			'singular_name' => __( 'Testimonial','vw-tourism-pro-posttype' )
  		),
  		'capability_type' => 'post',
  		'menu_icon'  => 'dashicons-admin-comments',
  		'public' => true,
  		'supports' => array(
  			'title',
  			'editor',
  			'thumbnail'
  		)
		)
	);
}

function vw_tourism_pro_posttype_create_popular_cuisines() {
  register_post_type('popular-cuisines',
    array(
  		'labels' => array(
  			'name' => __( 'Popular Cuisines','vw-tourism-pro-posttype' ),
  			'singular_name' => __( 'Popular Cuisines','vw-tourism-pro-posttype' )
  		),
  		'capability_type' => 'post',
  		'menu_icon'  => 'dashicons-food',
  		'public' => true,
  		'supports' => array(
  			'title',
  			'editor',
  			'thumbnail'
  		)
		)
	);
}
function vw_tourism_pro_posttype_create_experience() {
  register_post_type('experience',
    array(
  		'labels' => array(
  			'name' => __( 'Experience','vw-tourism-pro-posttype' ),
  			'singular_name' => __( 'Experience','vw-tourism-pro-posttype' )
  		),
  		'capability_type' => 'post',
  		'menu_icon'  => 'dashicons-smiley',
  		'public' => true,
  		'supports' => array(
  			'title',
  			'editor',
  			'thumbnail'
  		)
		)
	);
}


/*----------------------Blog Section ----------------------*/

// Blog Post section

function vw_tourism_pro_posttype_bn_blog_meta_box() {
	add_meta_box( 'vw-tourism-pro-posttype-blog-meta', __( 'Enter Details', 'vw-tourism-pro-posttype' ), 'vw_tourism_pro_posttype_bn_blog_meta_callback', 'post', 'normal', 'high' );
}
// Hook things in for admin
if (is_admin()){
    add_action('admin_menu', 'vw_tourism_pro_posttype_bn_blog_meta_box');
}
/* Adds a meta box for custom post */
function vw_tourism_pro_posttype_bn_blog_meta_callback( $post ) {
	wp_nonce_field( basename( __FILE__ ), 'vw_tourism_pro_posttype_posttype_blog_meta_nonce' );
  //$bn_stored_meta = get_post_meta( $post->ID );
	$blog_para = get_post_meta( $post->ID, 'post-ques', true );
	$blog_text = get_post_meta( $post->ID, 'post-para-one', true );

	?>
	<div id="posts_custom_stuff">
		<table id="list">
			<tbody id="the-list" data-wp-lists="list:meta">
				<tr id="meta-1">
					<td class="left">
						<?php _e( 'Post Question', 'vw-tourism-pro-posttype' )?>
					</td>
					<td class="left" >
						<input type="text" name="post-ques" id="post-ques" value="<?php echo esc_attr( $blog_para ); ?>" />
					</td>
				</tr>
				<tr id="meta-2">
					<td class="left">
						<?php _e( 'Blog Paragraph 1', 'vw-tourism-pro-posttype' )?>
					</td>
					<td class="left" >
						<input type="text" name="post-para-one" id="post-para-one" value="<?php echo esc_attr( $blog_text ); ?>" />
					</td>
				</tr>


			</tbody>
		</table>
	</div>
	<?php
}

/* Saves the custom meta input */
function vw_tourism_pro_posttype_bn_blog_post_meta_save( $post_id ) {
	if (!isset($_POST['vw_tourism_pro_posttype_posttype_blog_meta_nonce']) || !wp_verify_nonce($_POST['vw_tourism_pro_posttype_posttype_blog_meta_nonce'], basename(__FILE__))) {
		return;
	}

	if (!current_user_can('edit_post', $post_id)) {
		return;
	}

	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
		return;
	}

	// Save desig.
	if( isset( $_POST[ 'post-ques' ] ) ) {
		update_post_meta( $post_id, 'post-ques', sanitize_text_field($_POST[ 'post-ques']) );
	}
	if( isset( $_POST[ 'post-para-one' ] ) ) {
		update_post_meta( $post_id, 'post-para-one', sanitize_text_field($_POST[ 'post-para-one']) );
	}

}

add_action( 'save_post', 'vw_tourism_pro_posttype_bn_blog_post_meta_save' );


function add_custom_meta_box() {
    add_meta_box(
        'repeater_fields_meta_box',
        'Repeater Fields',
        'render_repeater_fields_meta_box',
        'post',
        'normal',
        'default'
    );
}
add_action('add_meta_boxes', 'add_custom_meta_box');

function render_repeater_fields_meta_box($post) {
    // Retrieve existing values from the database
    $repeater_fields = get_post_meta($post->ID, 'post_repeater_fields', true);

    // Output the repeater fields form
    ?>
    <div>
        <ul id="repeater_fields_container">
            <?php if ($repeater_fields) : ?>
                <?php foreach ($repeater_fields as $index => $field) : ?>
                    <li>
                        <label for="repeater_field_<?php echo $index; ?>">Points:</label>
                        <input type="text" name="repeater_fields[<?php echo $index; ?>][points]" value="<?php echo esc_attr($field['points']); ?>">
                        <!-- Add more fields here as needed -->
                    </li>
                <?php endforeach; ?>
            <?php endif; ?>
        </ul>
        <button id="add_repeater_field">Add Field</button>
    </div>
    <script>
        // JavaScript to handle adding new repeater fields
        document.getElementById('add_repeater_field').addEventListener('click', function(event) {
            event.preventDefault();
            var container = document.getElementById('repeater_fields_container');
            var newIndex = container.querySelectorAll('li').length;
            var newItem = document.createElement('li');
            newItem.innerHTML = '<label for="repeater_field_' + newIndex + '">Points:</label>' +
                                '<input type="text" name="repeater_fields[' + newIndex + '][points]" value="">';
            container.appendChild(newItem);
        });
    </script>
    <?php
}

function save_custom_meta_box_data($post_id) {
    // Save repeater fields data
    if (isset($_POST['repeater_fields'])) {
        $repeater_fields = $_POST['repeater_fields'];
        $cleaned_fields = array();

        foreach ($repeater_fields as $index => $field) {
            // Check if the title is not empty
            if (!empty($field['points'])) {
                $cleaned_fields[$index] = array(
                    'points' => sanitize_text_field($field['points'])
                    // You can add more fields here if needed
                );
            }
        }

        // Update post meta with cleaned repeater fields
        if (!empty($cleaned_fields)) {
            update_post_meta($post_id, 'post_repeater_fields', $cleaned_fields);
        } else {
            // If all fields were empty, delete the meta
            delete_post_meta($post_id, 'post_repeater_fields');
        }
    }
}
add_action('save_post', 'save_custom_meta_box_data');

/*----------------------Testimonial section ----------------------*/

function vw_tourism_pro_posttype_testimonial_meta_box() {
	add_meta_box( 'vw-tourism-pro-posttype-testimonial-meta', __( 'Enter Details', 'vw-tourism-pro-posttype' ), 'vw_tourism_pro_posttype_bn_testimonial_meta_callback', 'testimonial', 'normal', 'high' );
}
//Hook things in for admin
if (is_admin()){
    add_action('admin_menu', 'vw_tourism_pro_posttype_testimonial_meta_box');
}

function vw_tourism_pro_posttype_bn_testimonial_meta_callback( $post ) {
	wp_nonce_field( basename( __FILE__ ), 'vw_tourism_pro_posttype_posttype_testimonial_meta_nonce' );
  $bn_stored_meta = get_post_meta( $post->ID );
	$testimonial_desigstory = get_post_meta( $post->ID, 'testimonial_desigstory', true );
  $testimonial_rating = get_post_meta( $post->ID, 'testimonial_rating', true );
	?>
	<div id="team_custom_stuff">
		<table id="list">
			<tbody id="the-list" data-wp-lists="list:meta">
				<tr id="meta-1">
					<td class="left">
						<?php _e( 'Testimonial Designation', 'vw-tourism-pro-posttype' )?>
					</td>
					<td class="left" >
						<input type="text" name="testimonial_desigstory" id="testimonial_desigstory" value="<?php echo esc_attr( $testimonial_desigstory ); ?>" />
					</td>
				</tr>
        <tr id="meta-2">
          <td class="left">
            <?php _e( 'Testimonial Ratings', 'vw-tourism-pro-posttype' )?>
          </td>
          <td class="left" >
            <input type="number" name="testimonial_rating" min="0" max="5" id="testimonial_rating" value="<?php echo esc_attr($testimonial_rating); ?>" />
          </td>
        </tr>
			</tbody>
		</table>
	</div>
	<?php
}
/* Saves the custom meta input */
function vw_tourism_pro_posttype_bn_testimonial_meta_save( $post_id ) {
	if (!isset($_POST['vw_tourism_pro_posttype_posttype_testimonial_meta_nonce']) || !wp_verify_nonce($_POST['vw_tourism_pro_posttype_posttype_testimonial_meta_nonce'], basename(__FILE__))) {
		return;
	}

	if (!current_user_can('edit_post', $post_id)) {
		return;
	}

	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
		return;
	}

	// Save desig.
	if( isset( $_POST[ 'testimonial_desigstory' ] ) ) {
		update_post_meta( $post_id, 'testimonial_desigstory', sanitize_text_field($_POST[ 'testimonial_desigstory']) );
	}
  if( isset( $_POST[ 'testimonial_rating' ] ) ) {
    update_post_meta( $post_id, 'testimonial_rating', sanitize_text_field($_POST[ 'testimonial_rating']) );
  }
}

add_action( 'save_post', 'vw_tourism_pro_posttype_bn_testimonial_meta_save' );



/*----------------------Popular Cuisines section ----------------------*/
function vw_tourism_pro_posttype_popular_cuisines_meta_box() {
	add_meta_box( 'vw-tourism-pro-posttype-popular-cuisines-meta', __( 'Enter Cuisines Details', 'vw-tourism-pro-posttype' ), 'vw_tourism_pro_posttype_bn_popular_cuisines_meta_callback', 'popular-cuisines', 'normal', 'high' );
}
//Hook things in for admin
if (is_admin()){
    add_action('admin_menu', 'vw_tourism_pro_posttype_popular_cuisines_meta_box');
}

function vw_tourism_pro_posttype_bn_popular_cuisines_meta_callback( $post ) {
	wp_nonce_field( basename( __FILE__ ), 'vw_tourism_pro_posttype_posttype_popular_cuisines_meta_nonce' );
  $bn_stored_meta = get_post_meta( $post->ID );
	$cuisines_price_title = get_post_meta( $post->ID, 'cuisines_price_title', true );
	$cuisines_price = get_post_meta( $post->ID, 'cuisines_price', true );
  $cuisines_sale_price = get_post_meta( $post->ID, 'cuisines_sale_price', true );
  $cuisines_location_title = get_post_meta( $post->ID, 'cuisines_location_title', true );
  $cuisines_location = get_post_meta( $post->ID, 'cuisines_location', true );
  $cuisines_recipe_title = get_post_meta( $post->ID, 'cuisines_recipe_title', true );
	?>
	<div id="team_custom_stuff">
		<table id="list">
			<tbody id="the-list" data-wp-lists="list:meta">
        <tr id="meta-1">
					<td class="left">
					<b><?php _e( 'Cusines Regular Title', 'vw-tourism-pro-posttype' )?></b>
					</td>
					<td class="left" >
						<input type="text" name="cuisines_price_title" id="cuisines_price_title" value="<?php echo esc_attr( $cuisines_price_title ); ?>" />
					</td>
				</tr>
				<tr id="meta-2">
					<td class="left">
					<b><?php _e( 'Cusines Regular Price', 'vw-tourism-pro-posttype' )?></b>
					</td>
					<td class="left" >
						<input type="number" name="cuisines_price" id="cuisines_price" value="<?php echo esc_attr( $cuisines_price ); ?>" />
					</td>
				</tr>
				<tr id="meta-3">
					<td class="left">
						<b><?php _e( 'Cusines Sale Price', 'vw-tourism-pro-posttype' )?></b>
					</td>
					<td class="left" >
						<input type="number" name="cuisines_sale_price" id="cuisines_sale_price" value="<?php echo esc_attr( $cuisines_sale_price ); ?>" />
					</td>
				</tr>
				<tr id="meta-4">
					<td class="left">
						<b><?php _e( 'Cusines Location Title', 'vw-tourism-pro-posttype' )?></b>
					</td>
					<td class="left" >
						<input type="text" name="cuisines_location_title" id="cuisines_location_title" value="<?php echo esc_attr( $cuisines_location_title ); ?>" />
					</td>
				</tr>
				<tr id="meta-5">
					<td class="left">
						<b><?php _e( 'Cusines Location', 'vw-tourism-pro-posttype' )?></b>
					</td>
					<td class="left" >
						<input type="text" name="cuisines_location" id="cuisines_location" value="<?php echo esc_attr( $cuisines_location ); ?>" />
					</td>
				</tr>
				<tr id="meta-5">
					<td class="left">
						<b><?php _e( 'Cusines Recipe Title', 'vw-tourism-pro-posttype' )?></b>
					</td>
					<td class="left" >
						<input type="text" name="cuisines_recipe_title" id="cuisines_recipe_title" value="<?php echo esc_attr( $cuisines_recipe_title ); ?>" />
					</td>
				</tr>
			</tbody>
		</table>
	</div>
	<?php
}
/* Saves the custom meta input */
function vw_tourism_pro_posttype_bn_popular_cuisines_meta_save( $post_id ) {
	if (!isset($_POST['vw_tourism_pro_posttype_posttype_popular_cuisines_meta_nonce']) || !wp_verify_nonce($_POST['vw_tourism_pro_posttype_posttype_popular_cuisines_meta_nonce'], basename(__FILE__))) {
		return;
	}

	if (!current_user_can('edit_post', $post_id)) {
		return;
	}

	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
		return;
	}

	// Save desig.
	if( isset( $_POST[ 'cuisines_price_title' ] ) ) {
		update_post_meta( $post_id, 'cuisines_price_title', sanitize_text_field($_POST[ 'cuisines_price_title']) );
	}
	if( isset( $_POST[ 'cuisines_price' ] ) ) {
		update_post_meta( $post_id, 'cuisines_price', sanitize_text_field($_POST[ 'cuisines_price']) );
	}
  if( isset( $_POST[ 'cuisines_sale_price' ] ) ) {
    update_post_meta( $post_id, 'cuisines_sale_price', sanitize_text_field($_POST[ 'cuisines_sale_price']) );
  }
  if( isset( $_POST[ 'cuisines_location_title' ] ) ) {
    update_post_meta( $post_id, 'cuisines_location_title', sanitize_text_field($_POST[ 'cuisines_location_title']) );
  }
  if( isset( $_POST[ 'cuisines_location' ] ) ) {
    update_post_meta( $post_id, 'cuisines_location', sanitize_text_field($_POST[ 'cuisines_location']) );
  }
  if( isset( $_POST[ 'cuisines_recipe_title' ] ) ) {
    update_post_meta( $post_id, 'cuisines_recipe_title', sanitize_text_field($_POST[ 'cuisines_recipe_title']) );
  }
}

add_action( 'save_post', 'vw_tourism_pro_posttype_bn_popular_cuisines_meta_save' );

/*----------------------Experience section ----------------------*/
function vw_tourism_pro_posttype_popular_experience_meta_box() {
	add_meta_box( 'vw-tourism-pro-posttype-experience-meta', __( 'Enter Experience Details', 'vw-tourism-pro-posttype' ), 'vw_tourism_pro_posttype_bn_experience_meta_callback', 'experience', 'normal', 'high' );
}
//Hook things in for admin
if (is_admin()){
    add_action('admin_menu', 'vw_tourism_pro_posttype_popular_experience_meta_box');
}
function vw_tourism_pro_posttype_bn_experience_meta_callback( $post ) {
	wp_nonce_field( basename( __FILE__ ), 'vw_tourism_pro_posttype_posttype_experience_nonce' );
  $bn_stored_meta = get_post_meta( $post->ID );
  $exp_img1 = get_post_meta($post->ID,'experience-img-one',true);
  $exp_img2 = get_post_meta($post->ID,'experience-img-two',true);
	?>
	<div id="experience-details">
		<table id="list">
			<tbody id="the-list" data-wp-lists="list:meta">
        <tr class="meta1">
            <th class="left">
              <?php _e( 'Image 1', 'vw-tourism-pro-posttype' )?></th>
            <td>
                <input type="text" name="experience-img-one" value="<?php echo $exp_img1; ?>" readonly>
                <input type="button" class="button button-primary" value="Upload Image" id="experience-img-one"><br>
            </td>
        </tr>
        <tr class="meta2">
            <th class="left">
              <?php _e( 'Image 2', 'vw-tourism-pro-posttype' )?></th>
            <td>
                <input type="text" name="experience-img-two" value="<?php echo $exp_img2; ?>" readonly>
                <input type="button" class="button button-primary" value="Upload Image" id="experience-img-two"><br>
            </td>
        </tr>
			</tbody>
		</table>
	</div>
	<?php
}

/* Saves the custom meta input */
function vw_tourism_pro_posttype_bn_experience_meta_save( $post_id ) {

	if (!isset($_POST['vw_tourism_pro_posttype_posttype_experience_nonce']) || !wp_verify_nonce($_POST['vw_tourism_pro_posttype_posttype_experience_nonce'], basename(__FILE__))) {
		return;
	}
	if (!current_user_can('edit_post', $post_id)) {
		return;
	}
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
		return;
	}

	// Save desig.
	if( isset( $_POST[ 'experience-img-one' ] ) ) {
		update_post_meta( $post_id, 'experience-img-one', sanitize_text_field($_POST[ 'experience-img-one']) );
	}
	if( isset( $_POST[ 'experience-img-two' ] ) ) {
		update_post_meta( $post_id, 'experience-img-two', sanitize_text_field($_POST[ 'experience-img-two']) );
	}
}
add_action( 'save_post', 'vw_tourism_pro_posttype_bn_experience_meta_save' );
