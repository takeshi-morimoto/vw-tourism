<?php
function create_explore_post_type() {
    $labels = array(
        'name'                  => _x( 'Explore', 'Post Type General Name', 'text_domain' ),
        'singular_name'         => _x( 'Explore', 'Post Type Singular Name', 'text_domain' ),
        'menu_name'             => __( 'Explore', 'text_domain' ),
        'name_admin_bar'        => __( 'Explore', 'text_domain' ),
        'archives'              => __( 'Explore Archives', 'text_domain' ),
        'attributes'            => __( 'Explore Attributes', 'text_domain' ),
        'parent_item_colon'     => __( 'Parent Explore:', 'text_domain' ),
        'all_items'             => __( 'All Explore', 'text_domain' ),
        'add_new_item'          => __( 'Add New Explore', 'text_domain' ),
        'add_new'               => __( 'Add New', 'text_domain' ),
        'new_item'              => __( 'New Explore', 'text_domain' ),
        'edit_item'             => __( 'Edit Explore', 'text_domain' ),
        'update_item'           => __( 'Update Explore', 'text_domain' ),
        'view_item'             => __( 'View Explore', 'text_domain' ),
        'view_items'            => __( 'View Explore', 'text_domain' ),
        'search_items'          => __( 'Search Explore', 'text_domain' ),
        'not_found'             => __( 'Not found', 'text_domain' ),
        'not_found_in_trash'    => __( 'Not found in Trash', 'text_domain' ),
        'featured_image'        => __( 'Featured Image', 'text_domain' ),
        'set_featured_image'    => __( 'Set featured image', 'text_domain' ),
        'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
        'use_featured_image'    => __( 'Use as featured image', 'text_domain' ),
        'insert_into_item'      => __( 'Insert into explore', 'text_domain' ),
        'uploaded_to_this_item' => __( 'Uploaded to this explore', 'text_domain' ),
        'items_list'            => __( 'Explore list', 'text_domain' ),
        'items_list_navigation' => __( 'Explore list navigation', 'text_domain' ),
        'filter_items_list'     => __( 'Filter Explore list', 'text_domain' ),
    );
    $args = array(
        'label'                 => __( 'Explore', 'text_domain' ),
        'description'           => __( 'Tourism Explore', 'text_domain' ),
        'labels'                => $labels,
        'supports'              => array( 'title', 'editor' ),
        'taxonomies'            => array(),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-admin-site-alt',
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'page',
    );
    register_post_type( 'tcp_explore', $args );
}
add_action( 'init', 'create_explore_post_type', 0 );

add_action('add_meta_boxes', 'add_explore_custom_meta_box');
function add_explore_custom_meta_box() {

    add_meta_box(
        'explore_custom_meta_box',
        'Additional Meta Fields',
        'render_explore_custom_meta_box',
        'tcp_explore',
        'normal',
        'default'
    );
}

function render_explore_custom_meta_box() {
    global $post;
    $meta = get_post_meta($post->ID, 'package_explore_meta_fields', true);
    wp_nonce_field('save_package_explore_meta_fields', 'package_explore_meta_fields_nonce'); ?>

    <style>
    .repeatable-field {
        width: 100%;
        margin-bottom: 10px;
    }
    .repeatable-field input[type="text"] {
        width: 80%;
        padding: 5px;
        margin-right: 10px;
    }
    .repeatable-field .button {
        width: 15%;
    }
    .upload_image_button {
        display: inline-block;
        margin: 5px 0;
    }
    .meta-image-preview {
        display: block;
        max-width: 150px;
        height: auto;
        margin-top: 10px;
    }
    </style>

    <table id="repeatable-fieldset-one" width="100%">
        <thead>
            <tr>
                <th width="30%">Image</th>
                <th width="15%">Text 1</th>
                <th width="15%">Text 2</th>
                <th width="15%">Text 3</th>
                <th width="15%">Text 4</th>
                <th width="10%">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php
        if ($meta) :
            foreach ($meta as $field) { ?>
                <tr>
                    <td>
                        <input type="hidden" name="explore_meta[image][]" class="meta-image" value="<?php if ($field['image'] != '') echo esc_attr($field['image']); ?>" />
                        <img class="meta-image-preview" src="<?php if ($field['image'] != '') echo esc_url($field['image']); ?>" />
                        <br>
                        <input type="button" class="button upload_image_button" value="Upload Image" />
                    </td>
                    <td><input type="text" name="explore_meta[text1][]" value="<?php if ($field['text1'] != '') echo esc_attr($field['text1']); ?>" /></td>
                    <td><input type="text" name="explore_meta[text2][]" value="<?php if ($field['text2'] != '') echo esc_attr($field['text2']); ?>" /></td>
                    <td><input type="text" name="explore_meta[text3][]" value="<?php if ($field['text3'] != '') echo esc_attr($field['text3']); ?>" /></td>
                    <td><input type="text" name="explore_meta[text4][]" value="<?php if ($field['text4'] != '') echo esc_attr($field['text4']); ?>" /></td>
                    <td><a class="button remove-row" href="#">Remove</a></td>
                </tr>
            <?php
            }
        else : ?>
            <tr>
                <td>
                    <input type="hidden" name="explore_meta[image][]" class="meta-image" />
                    <img class="meta-image-preview" src="" style="max-width: 150px; height: auto;" />
                    <br>
                    <input type="button" class="button upload_image_button" value="Upload Image" />
                </td>
                <td><input type="text" name="explore_meta[text1][]" /></td>
                <td><input type="text" name="explore_meta[text2][]" /></td>
                <td><input type="text" name="explore_meta[text3][]" /></td>
                <td><input type="text" name="explore_meta[text4][]" /></td>
                <td><a class="button remove-row" href="#">Remove</a></td>
            </tr>
        <?php endif; ?>

        <tr class="empty-row screen-reader-text">
            <td>
                <input type="hidden" name="explore_meta[image][]" class="meta-image" />
                <img class="meta-image-preview" src="" style="max-width: 150px; height: auto;" />
                <br>
                <input type="button" class="button upload_image_button" value="Upload Image" />
            </td>
            <td><input type="text" name="explore_meta[text1][]" /></td>
            <td><input type="text" name="explore_meta[text2][]" /></td>
            <td><input type="text" name="explore_meta[text3][]" /></td>
            <td><input type="text" name="explore_meta[text4][]" /></td>
            <td><a class="button remove-row" href="#">Remove</a></td>
        </tr>
        </tbody>
    </table>

    <p><a id="add-row" class="button" href="#">Add another</a></p>

    <script>
    jQuery(document).ready(function($) {
        // Add row
        $('#add-row').on('click', function() {
            var row = $('.empty-row.screen-reader-text').clone(true);
            row.removeClass('empty-row screen-reader-text');
            row.insertBefore('#repeatable-fieldset-one tbody>tr:last');
            return false;
        });

        // Remove row
        $('.remove-row').on('click', function() {
            $(this).parents('tr').remove();
            return false;
        });

        $(document).on('click', '.upload_image_button', function(event) {
            event.preventDefault();
            var $el = $(this).closest('td');
            var meta_image_frame;

            // Create the media frame.
            meta_image_frame = wp.media({
                title: 'Choose or Upload an Image',
                button: { text: 'Use this image' },
                library: { type: 'image' }
            });

            // When an image is selected, run a callback.
            meta_image_frame.on('select', function() {
                var media_attachment = meta_image_frame.state().get('selection').first().toJSON();
                $el.find('.meta-image').val(media_attachment.url);
                $el.find('.meta-image-preview').attr('src', media_attachment.url);
            });

            // Finally, open the modal.
            meta_image_frame.open();
        });
    });
    </script>
<?php
}

function save_explore_meta($post_id) {

    if (!isset($_POST['package_explore_meta_fields_nonce'])) {
        return $post_id;
    }
    $nonce = $_POST['package_explore_meta_fields_nonce'];

    if (!wp_verify_nonce($nonce, 'save_package_explore_meta_fields')) {
        return $post_id;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    }

    if (isset($_POST['post_type']) && 'page' == $_POST['post_type']) {
        if (!current_user_can('edit_page', $post_id)) {
            return $post_id;
        }
    } else {
        if (!current_user_can('edit_post', $post_id)) {
            return $post_id;
        }
    }

    if (!isset($_POST['explore_meta'])) {
        return $post_id;
    }

    $meta = array();
    $image = $_POST['explore_meta']['image'];
    $text1 = $_POST['explore_meta']['text1'];
    $text2 = $_POST['explore_meta']['text2'];
    $text3 = $_POST['explore_meta']['text3'];
    $text4 = $_POST['explore_meta']['text4'];

    foreach ($text1 as $key => $value) {
        if ($value) {
            $meta[$key]['text1'] = $value;
            $meta[$key]['text2'] = $text2[$key];
            $meta[$key]['text3'] = $text3[$key];
            $meta[$key]['text4'] = $text4[$key];
            $meta[$key]['image'] = $image[$key];
        }
    }
    update_post_meta($post_id, 'package_explore_meta_fields', $meta);
}
add_action('save_post', 'save_explore_meta');
